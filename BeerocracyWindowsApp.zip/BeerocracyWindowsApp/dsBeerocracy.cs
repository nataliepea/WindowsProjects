﻿namespace BeerocracyWindowsApp
{


    partial class dsBeerocracy
    {
    }
}

namespace BeerocracyWindowsApp.dsBeerocracyTableAdapters
{
	partial class BeerIngredientTableAdapter
	{
	}

	public partial class BeerTableAdapter {
    }
}
